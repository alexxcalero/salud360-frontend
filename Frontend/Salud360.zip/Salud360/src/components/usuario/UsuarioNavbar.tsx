import UnderConstruction from "@/pages/UnderConstruction";

function UsuarioNavbar(){
    return(
        <div>
            <UnderConstruction/>
        </div>
    )
}

export default UsuarioNavbar;