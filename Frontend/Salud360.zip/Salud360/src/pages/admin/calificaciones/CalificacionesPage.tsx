import UnderConstruction from "@/pages/UnderConstruction";

function CalificacionesPage(){
    return <UnderConstruction/>;
}

export default CalificacionesPage;