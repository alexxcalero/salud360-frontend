import UnderConstruction from "@/pages/UnderConstruction";

function AuditoriasPage(){
    return <UnderConstruction/>;
}

export default AuditoriasPage;