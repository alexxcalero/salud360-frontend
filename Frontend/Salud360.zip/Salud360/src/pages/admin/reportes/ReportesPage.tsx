import UnderConstruction from "@/pages/UnderConstruction";

function ReportesPage(){
    return <UnderConstruction/>;
}

export default ReportesPage;