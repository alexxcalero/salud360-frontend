import UnderConstruction from "@/pages/UnderConstruction";

function LogsPage(){
    return <UnderConstruction/>;
}

export default LogsPage;