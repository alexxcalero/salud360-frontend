import UnderConstruction from "@/pages/UnderConstruction";

function DashboardPage(){
    return <UnderConstruction/>;
}

export default DashboardPage;