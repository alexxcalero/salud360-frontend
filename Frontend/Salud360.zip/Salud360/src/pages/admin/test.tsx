function test() {
  return (
    <div>
      <h2>test</h2>
    </div>
  );
}

export default test;
