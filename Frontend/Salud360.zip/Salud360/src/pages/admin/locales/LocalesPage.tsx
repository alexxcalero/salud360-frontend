import UnderConstruction from "@/pages/UnderConstruction";

function LocalesPage(){
    return <UnderConstruction/>;
}

export default LocalesPage;