import UnderConstruction from "@/pages/UnderConstruction";

function CrearMedico(){
    return (
        <div>
            <UnderConstruction/>
        </div>
    )
}

export default CrearMedico;