import UnderConstruction from "@/pages/UnderConstruction";

function MembresiasPage(){
    return <UnderConstruction/>;
}

export default MembresiasPage;