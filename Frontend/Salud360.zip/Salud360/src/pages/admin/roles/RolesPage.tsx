import UnderConstruction from "@/pages/UnderConstruction";

function RolesPage(){
    return <UnderConstruction/>;
}

export default RolesPage;