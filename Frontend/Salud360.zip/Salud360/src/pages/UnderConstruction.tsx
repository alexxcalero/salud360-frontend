function UnderConstruction(){
    return (
        <img src="https://pngimg.com/d/under_construction_PNG18.png" alt="hola" />
    )
}

export default UnderConstruction;