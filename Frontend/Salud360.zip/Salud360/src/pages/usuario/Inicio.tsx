import UnderConstruction from "../UnderConstruction";

function Inicio(){
    return (
        <div>
            <UnderConstruction/>
        </div>
    )
}

export default Inicio;