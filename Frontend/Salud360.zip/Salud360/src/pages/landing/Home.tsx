import UnderConstruction from "../UnderConstruction";

function Home(){
    return (
        <div>
            <UnderConstruction/>
            <h1 className="bg-emerald-500">Revisar main.tsx para ver las rutas</h1>
            <UnderConstruction/>
            <h1 className="bg-emerald-500">Revisar main.tsx para ver las rutas</h1>
            <UnderConstruction/>
        </div>
    )
}

export default Home;